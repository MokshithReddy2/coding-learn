import { PlatformHeader } from "@/components/platform-header"
import { PlatformSidebar } from "@/components/platform-sidebar"
import { CodeEditor } from "@/components/code-editor"
import { ErrorPanel } from "@/components/error-panel"
import { TutorialPanel } from "@/components/tutorial-panel"
import { ProgressTracker } from "@/components/progress-tracker"
import { DebugPanel } from "@/components/debug-panel"
import { ExerciseGenerator } from "@/components/exercise-generator"

export default function PlatformPage() {
  return (
    <div className="min-h-screen bg-background">
      <PlatformHeader />
      <div className="flex h-[calc(100vh-4rem)]">
        <PlatformSidebar />
        <main className="flex-1 flex flex-col">
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 p-4">
            {/* Code Editor Section */}
            <div className="lg:col-span-2 space-y-4">
              <CodeEditor />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <ErrorPanel />
                <DebugPanel />
              </div>
            </div>

            {/* Tutorial and Progress Section */}
            <div className="space-y-4">
              <ProgressTracker />
              <TutorialPanel />
              <ExerciseGenerator />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
