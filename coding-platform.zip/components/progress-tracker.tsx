"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, Trophy, Star, Award, Zap, Calendar, CheckCircle } from "lucide-react"

interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  earned: boolean
  earnedDate?: Date
  points: number
}

interface SkillProgress {
  skill: string
  level: number
  progress: number
  totalExercises: number
  completedExercises: number
}

interface LearningStreak {
  current: number
  longest: number
  lastActivity: Date
}

export function ProgressTracker() {
  const [achievements] = useState<Achievement[]>([
    {
      id: "first-code",
      title: "First Steps",
      description: "Write your first line of code",
      icon: "🎯",
      earned: true,
      earnedDate: new Date("2024-01-15"),
      points: 10,
    },
    {
      id: "debug-master",
      title: "Debug Master",
      description: "Fix 10 bugs using the debugger",
      icon: "🐛",
      earned: true,
      earnedDate: new Date("2024-01-18"),
      points: 50,
    },
    {
      id: "array-expert",
      title: "Array Expert",
      description: "Complete all array exercises",
      icon: "📊",
      earned: false,
      points: 75,
    },
    {
      id: "speed-coder",
      title: "Speed Coder",
      description: "Complete an exercise in under 5 minutes",
      icon: "⚡",
      earned: false,
      points: 25,
    },
    {
      id: "streak-warrior",
      title: "Streak Warrior",
      description: "Maintain a 7-day learning streak",
      icon: "🔥",
      earned: true,
      earnedDate: new Date("2024-01-20"),
      points: 100,
    },
  ])

  const [skillProgress] = useState<SkillProgress[]>([
    {
      skill: "JavaScript Basics",
      level: 2,
      progress: 75,
      totalExercises: 20,
      completedExercises: 15,
    },
    {
      skill: "Arrays & Objects",
      level: 1,
      progress: 40,
      totalExercises: 15,
      completedExercises: 6,
    },
    {
      skill: "Functions",
      level: 1,
      progress: 60,
      totalExercises: 12,
      completedExercises: 7,
    },
    {
      skill: "DOM Manipulation",
      level: 0,
      progress: 20,
      totalExercises: 18,
      completedExercises: 3,
    },
  ])

  const [learningStreak] = useState<LearningStreak>({
    current: 5,
    longest: 12,
    lastActivity: new Date(),
  })

  const totalPoints = achievements.filter((a) => a.earned).reduce((sum, a) => sum + a.points, 0)
  const earnedAchievements = achievements.filter((a) => a.earned).length
  const overallProgress = skillProgress.reduce((sum, skill) => sum + skill.progress, 0) / skillProgress.length

  const getSkillLevelColor = (level: number) => {
    switch (level) {
      case 0:
        return "text-gray-500"
      case 1:
        return "text-blue-500"
      case 2:
        return "text-green-500"
      case 3:
        return "text-yellow-500"
      default:
        return "text-purple-500"
    }
  }

  const getSkillLevelName = (level: number) => {
    switch (level) {
      case 0:
        return "Beginner"
      case 1:
        return "Novice"
      case 2:
        return "Intermediate"
      case 3:
        return "Advanced"
      default:
        return "Expert"
    }
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          Progress Tracker
        </CardTitle>
      </CardHeader>

      <CardContent className="p-0">
        <Tabs defaultValue="overview" className="h-full">
          <TabsList className="grid w-full grid-cols-3 rounded-none border-b">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="skills">Skills</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-0 p-4 space-y-4">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Star className="w-4 h-4 text-yellow-500" />
                  <span className="text-sm font-medium">Total Points</span>
                </div>
                <div className="text-2xl font-bold">{totalPoints}</div>
              </div>

              <div className="p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Trophy className="w-4 h-4 text-secondary" />
                  <span className="text-sm font-medium">Achievements</span>
                </div>
                <div className="text-2xl font-bold">
                  {earnedAchievements}/{achievements.length}
                </div>
              </div>
            </div>

            {/* Learning Streak */}
            <div className="p-4 bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-950/30 dark:to-red-950/30 rounded-lg border">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="text-2xl">🔥</div>
                  <div>
                    <div className="font-semibold">Learning Streak</div>
                    <div className="text-sm text-muted-foreground">Keep it up!</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">{learningStreak.current}</div>
                  <div className="text-sm text-muted-foreground">days</div>
                </div>
              </div>
              <div className="text-xs text-muted-foreground">Longest streak: {learningStreak.longest} days</div>
            </div>

            {/* Overall Progress */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Overall Progress</span>
                <span className="text-sm text-muted-foreground">{Math.round(overallProgress)}%</span>
              </div>
              <Progress value={overallProgress} className="h-2" />
            </div>

            {/* Recent Activity */}
            <div className="space-y-2">
              <h4 className="text-sm font-medium flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Recent Activity
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between p-2 bg-muted/30 rounded">
                  <span>Completed "Array Methods" exercise</span>
                  <span className="text-muted-foreground">2 hours ago</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted/30 rounded">
                  <span>Earned "Debug Master" achievement</span>
                  <span className="text-muted-foreground">1 day ago</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted/30 rounded">
                  <span>Started "Functions" tutorial</span>
                  <span className="text-muted-foreground">2 days ago</span>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="skills" className="mt-0 p-4 space-y-4">
            {skillProgress.map((skill, index) => (
              <div key={index} className="space-y-3 p-3 border rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">{skill.skill}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className={getSkillLevelColor(skill.level)}>
                        Level {skill.level} - {getSkillLevelName(skill.level)}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        {skill.completedExercises}/{skill.totalExercises} exercises
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium">{skill.progress}%</div>
                  </div>
                </div>

                <Progress value={skill.progress} className="h-2" />

                {skill.progress === 100 && skill.level < 3 && (
                  <Button size="sm" variant="secondary" className="w-full">
                    <Zap className="w-4 h-4 mr-2" />
                    Level Up Available!
                  </Button>
                )}
              </div>
            ))}
          </TabsContent>

          <TabsContent value="achievements" className="mt-0 p-4 space-y-3">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-3 border rounded-lg ${
                  achievement.earned ? "bg-muted/30 border-secondary" : "opacity-60"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="text-2xl">{achievement.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium">{achievement.title}</h4>
                      {achievement.earned && <CheckCircle className="w-4 h-4 text-green-500" />}
                    </div>
                    <p className="text-sm text-muted-foreground">{achievement.description}</p>
                    {achievement.earnedDate && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Earned on {achievement.earnedDate.toLocaleDateString()}
                      </p>
                    )}
                  </div>
                  <div className="text-right">
                    <Badge variant={achievement.earned ? "secondary" : "outline"}>{achievement.points} pts</Badge>
                  </div>
                </div>
              </div>
            ))}

            <div className="text-center py-4">
              <Button variant="outline" size="sm">
                <Award className="w-4 h-4 mr-2" />
                View All Achievements
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
