"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Shuffle, Zap, Target, Clock, Star, RefreshCw } from "lucide-react"

interface Exercise {
  id: string
  title: string
  description: string
  difficulty: "beginner" | "intermediate" | "advanced"
  topic: string
  estimatedTime: number
  points: number
  template: string
  solution: string
  testCases: TestCase[]
}

interface TestCase {
  input: string
  expectedOutput: string
  description: string
}

const exerciseTemplates: Exercise[] = [
  {
    id: "1",
    title: "Array Sum Calculator",
    description: "Write a function that calculates the sum of all numbers in an array",
    difficulty: "beginner",
    topic: "Arrays",
    estimatedTime: 10,
    points: 50,
    template: `function calculateSum(numbers) {
  // Your code here
  
}

// Test your function
console.log(calculateSum([1, 2, 3, 4, 5])); // Should return 15`,
    solution: `function calculateSum(numbers) {
  return numbers.reduce((sum, num) => sum + num, 0);
}`,
    testCases: [
      { input: "[1, 2, 3, 4, 5]", expectedOutput: "15", description: "Sum of positive numbers" },
      { input: "[-1, -2, -3]", expectedOutput: "-6", description: "Sum of negative numbers" },
      { input: "[]", expectedOutput: "0", description: "Empty array" },
    ],
  },
  {
    id: "2",
    title: "String Palindrome Checker",
    description: "Create a function that checks if a string is a palindrome (reads the same forwards and backwards)",
    difficulty: "intermediate",
    topic: "Strings",
    estimatedTime: 15,
    points: 75,
    template: `function isPalindrome(str) {
  // Your code here
  
}

// Test your function
console.log(isPalindrome("racecar")); // Should return true
console.log(isPalindrome("hello")); // Should return false`,
    solution: `function isPalindrome(str) {
  const cleaned = str.toLowerCase().replace(/[^a-z0-9]/g, '');
  return cleaned === cleaned.split('').reverse().join('');
}`,
    testCases: [
      { input: '"racecar"', expectedOutput: "true", description: "Simple palindrome" },
      { input: '"A man a plan a canal Panama"', expectedOutput: "true", description: "Palindrome with spaces" },
      { input: '"hello"', expectedOutput: "false", description: "Not a palindrome" },
    ],
  },
  {
    id: "3",
    title: "Fibonacci Sequence Generator",
    description: "Implement a function that generates the first n numbers in the Fibonacci sequence",
    difficulty: "advanced",
    topic: "Algorithms",
    estimatedTime: 25,
    points: 100,
    template: `function fibonacci(n) {
  // Your code here
  
}

// Test your function
console.log(fibonacci(8)); // Should return [0, 1, 1, 2, 3, 5, 8, 13]`,
    solution: `function fibonacci(n) {
  if (n <= 0) return [];
  if (n === 1) return [0];
  if (n === 2) return [0, 1];
  
  const result = [0, 1];
  for (let i = 2; i < n; i++) {
    result[i] = result[i - 1] + result[i - 2];
  }
  return result;
}`,
    testCases: [
      { input: "8", expectedOutput: "[0, 1, 1, 2, 3, 5, 8, 13]", description: "First 8 Fibonacci numbers" },
      { input: "1", expectedOutput: "[0]", description: "Single number" },
      { input: "0", expectedOutput: "[]", description: "Empty sequence" },
    ],
  },
]

const topics = ["Arrays", "Strings", "Objects", "Functions", "Algorithms", "DOM", "Async/Await"]
const difficulties = ["beginner", "intermediate", "advanced"]

export function ExerciseGenerator() {
  const [selectedTopics, setSelectedTopics] = useState<string[]>(["Arrays"])
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("beginner")
  const [timeLimit, setTimeLimit] = useState([15])
  const [currentExercise, setCurrentExercise] = useState<Exercise | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)

  const generateExercise = () => {
    setIsGenerating(true)

    // Simulate AI generation delay
    setTimeout(() => {
      const filteredExercises = exerciseTemplates.filter(
        (exercise) =>
          selectedTopics.includes(exercise.topic) &&
          exercise.difficulty === selectedDifficulty &&
          exercise.estimatedTime <= timeLimit[0],
      )

      if (filteredExercises.length > 0) {
        const randomExercise = filteredExercises[Math.floor(Math.random() * filteredExercises.length)]
        setCurrentExercise(randomExercise)
      } else {
        // Fallback to any exercise if no matches
        setCurrentExercise(exerciseTemplates[0])
      }

      setIsGenerating(false)
    }, 2000)
  }

  const toggleTopic = (topic: string) => {
    setSelectedTopics((prev) => (prev.includes(topic) ? prev.filter((t) => t !== topic) : [...prev, topic]))
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "intermediate":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "advanced":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Zap className="w-5 h-5" />
          Exercise Generator
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Configuration Panel */}
        <div className="space-y-4 p-4 bg-muted/30 rounded-lg">
          <h3 className="font-medium text-sm">Generate Custom Exercise</h3>

          {/* Topic Selection */}
          <div>
            <label className="text-sm font-medium mb-2 block">Topics</label>
            <div className="flex flex-wrap gap-2">
              {topics.map((topic) => (
                <div key={topic} className="flex items-center space-x-2">
                  <Checkbox
                    id={topic}
                    checked={selectedTopics.includes(topic)}
                    onCheckedChange={() => toggleTopic(topic)}
                  />
                  <label htmlFor={topic} className="text-sm">
                    {topic}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Difficulty Selection */}
          <div>
            <label className="text-sm font-medium mb-2 block">Difficulty</label>
            <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {difficulties.map((difficulty) => (
                  <SelectItem key={difficulty} value={difficulty}>
                    {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Time Limit */}
          <div>
            <label className="text-sm font-medium mb-2 block">Time Limit: {timeLimit[0]} minutes</label>
            <Slider value={timeLimit} onValueChange={setTimeLimit} max={60} min={5} step={5} className="w-full" />
          </div>

          <Button onClick={generateExercise} disabled={isGenerating} className="w-full">
            {isGenerating ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Shuffle className="w-4 h-4 mr-2" />
                Generate Exercise
              </>
            )}
          </Button>
        </div>

        {/* Generated Exercise */}
        {currentExercise && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">{currentExercise.title}</h3>
              <div className="flex items-center gap-2">
                <Badge className={getDifficultyColor(currentExercise.difficulty)}>{currentExercise.difficulty}</Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {currentExercise.estimatedTime}m
                </Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  <Star className="w-3 h-3" />
                  {currentExercise.points} pts
                </Badge>
              </div>
            </div>

            <p className="text-sm text-muted-foreground">{currentExercise.description}</p>

            {/* Code Template */}
            <div className="bg-muted p-4 rounded-lg">
              <h4 className="text-sm font-medium mb-2">Starting Template:</h4>
              <pre className="text-sm font-mono bg-background p-3 rounded border overflow-x-auto">
                {currentExercise.template}
              </pre>
            </div>

            {/* Test Cases */}
            <div>
              <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                <Target className="w-4 h-4" />
                Test Cases
              </h4>
              <ScrollArea className="h-32">
                <div className="space-y-2">
                  {currentExercise.testCases.map((testCase, index) => (
                    <div key={index} className="p-3 bg-muted/50 rounded border text-sm">
                      <div className="font-medium">{testCase.description}</div>
                      <div className="font-mono text-xs text-muted-foreground mt-1">
                        Input: {testCase.input} → Expected: {testCase.expectedOutput}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>

            <div className="flex gap-2">
              <Button className="flex-1">Start Exercise</Button>
              <Button variant="outline">View Solution</Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
