"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Play, RotateCcw, Copy, Maximize2 } from "lucide-react"

interface CodeError {
  line: number
  column: number
  message: string
  type: "error" | "warning"
}

export function CodeEditor() {
  const [code, setCode] = useState(`// Welcome to CodeLearn!
// Let's practice working with arrays and objects

const students = [
  { name: "Alice", grade: 85, subject: "Math" },
  { name: "Bob", grade: 92, subject: "Science" },
  { name: "Charlie", grade: 78, subject: "Math" }
];

// TODO: Write a function to find the average grade
function calculateAverage(studentArray) {
  // Your code here
  
}

// TODO: Filter students with grades above 80
function getTopStudents(studentArray) {
  // Your code here
  
}

console.log("Average grade:", calculateAverage(students));
console.log("Top students:", getTopStudents(students));`)

  const [output, setOutput] = useState("")
  const [errors, setErrors] = useState<CodeError[]>([])
  const [isRunning, setIsRunning] = useState(false)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // Simulate code analysis and error detection
  const analyzeCode = (codeText: string) => {
    const lines = codeText.split("\n")
    const detectedErrors: CodeError[] = []

    lines.forEach((line, index) => {
      // Simple error detection patterns
      if (line.includes("function") && !line.includes("{") && !line.includes(";")) {
        detectedErrors.push({
          line: index + 1,
          column: 1,
          message: "Function declaration should end with opening brace",
          type: "error",
        })
      }

      if (line.includes("console.log") && line.includes("undefined")) {
        detectedErrors.push({
          line: index + 1,
          column: line.indexOf("undefined"),
          message: "Variable may be undefined",
          type: "warning",
        })
      }

      // Check for incomplete functions
      if (line.includes("// Your code here") && index > 0) {
        detectedErrors.push({
          line: index + 1,
          column: 1,
          message: "Function implementation is incomplete",
          type: "warning",
        })
      }
    })

    setErrors(detectedErrors)
  }

  const runCode = async () => {
    setIsRunning(true)
    setOutput("Running code...\n")

    // Simulate code execution
    setTimeout(() => {
      try {
        // Simple simulation of code execution
        let result = ""

        if (code.includes("calculateAverage") && code.includes("return")) {
          result += "Average grade: 85\n"
        } else {
          result += "Average grade: undefined\n"
        }

        if (code.includes("getTopStudents") && code.includes("filter")) {
          result += 'Top students: [{ name: "Alice", grade: 85 }, { name: "Bob", grade: 92 }]\n'
        } else {
          result += "Top students: undefined\n"
        }

        setOutput(result)
      } catch (error) {
        setOutput(`Error: ${error}`)
      }
      setIsRunning(false)
    }, 1500)
  }

  const resetCode = () => {
    setCode(`// Welcome to CodeLearn!
// Let's practice working with arrays and objects

const students = [
  { name: "Alice", grade: 85, subject: "Math" },
  { name: "Bob", grade: 92, subject: "Science" },
  { name: "Charlie", grade: 78, subject: "Math" }
];

// TODO: Write a function to find the average grade
function calculateAverage(studentArray) {
  // Your code here
  
}

// TODO: Filter students with grades above 80
function getTopStudents(studentArray) {
  // Your code here
  
}

console.log("Average grade:", calculateAverage(students));
console.log("Top students:", getTopStudents(students));`)
    setOutput("")
    setErrors([])
  }

  const copyCode = () => {
    navigator.clipboard.writeText(code)
  }

  useEffect(() => {
    analyzeCode(code)
  }, [code])

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CardTitle className="text-lg">Code Editor</CardTitle>
            <Badge variant="outline" className="text-xs">
              JavaScript
            </Badge>
            {errors.length > 0 && (
              <Badge variant="destructive" className="text-xs">
                {errors.filter((e) => e.type === "error").length} errors,{" "}
                {errors.filter((e) => e.type === "warning").length} warnings
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={copyCode}>
              <Copy className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={resetCode}>
              <RotateCcw className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm">
              <Maximize2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Tabs defaultValue="editor" className="h-full">
          <TabsList className="grid w-full grid-cols-2 rounded-none border-b">
            <TabsTrigger value="editor">Editor</TabsTrigger>
            <TabsTrigger value="output">Output</TabsTrigger>
          </TabsList>

          <TabsContent value="editor" className="mt-0 h-[400px]">
            <div className="relative h-full">
              <textarea
                ref={textareaRef}
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full h-full p-4 font-mono text-sm bg-card border-0 resize-none focus:outline-none code-editor"
                placeholder="Write your code here..."
                spellCheck={false}
              />

              {/* Line numbers */}
              <div className="absolute left-0 top-0 p-4 text-xs text-muted-foreground font-mono pointer-events-none select-none">
                {code.split("\n").map((_, index) => (
                  <div key={index} className="h-5 leading-5">
                    {index + 1}
                  </div>
                ))}
              </div>

              {/* Error indicators */}
              {errors.map((error, index) => (
                <div
                  key={index}
                  className="absolute right-2 text-xs px-2 py-1 rounded bg-destructive text-destructive-foreground"
                  style={{ top: `${error.line * 20 + 60}px` }}
                  title={error.message}
                >
                  {error.type === "error" ? "❌" : "⚠️"}
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="output" className="mt-0 h-[400px]">
            <div className="h-full p-4 bg-muted font-mono text-sm overflow-auto">
              <div className="flex items-center justify-between mb-4">
                <span className="text-muted-foreground">Console Output</span>
                <Button size="sm" onClick={runCode} disabled={isRunning} className="bg-secondary hover:bg-secondary/90">
                  <Play className="w-4 h-4 mr-2" />
                  {isRunning ? "Running..." : "Run Code"}
                </Button>
              </div>
              <pre className="whitespace-pre-wrap text-foreground">{output || 'Click "Run Code" to see output...'}</pre>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
