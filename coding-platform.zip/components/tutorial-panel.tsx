"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Progress } from "@/components/ui/progress"
import { BookOpen, ChevronLeft, ChevronRight, Play, CheckCircle, Circle, Lightbulb, Code } from "lucide-react"

interface TutorialStep {
  id: number
  title: string
  content: string
  codeExample?: string
  hint?: string
  interactive?: boolean
  completed: boolean
}

interface Tutorial {
  id: string
  title: string
  description: string
  difficulty: "beginner" | "intermediate" | "advanced"
  estimatedTime: number
  steps: TutorialStep[]
}

const currentTutorial: Tutorial = {
  id: "arrays-objects",
  title: "Working with Arrays and Objects",
  description: "Learn how to manipulate arrays and objects in JavaScript",
  difficulty: "beginner",
  estimatedTime: 20,
  steps: [
    {
      id: 1,
      title: "Introduction to Arrays",
      content:
        "Arrays are ordered collections of items. In JavaScript, you can store different types of data in arrays.",
      codeExample: `const fruits = ['apple', 'banana', 'orange'];
console.log(fruits[0]); // 'apple'
console.log(fruits.length); // 3`,
      completed: true,
    },
    {
      id: 2,
      title: "Array Methods - Push and Pop",
      content: "Use push() to add items to the end of an array, and pop() to remove the last item.",
      codeExample: `const numbers = [1, 2, 3];
numbers.push(4); // [1, 2, 3, 4]
const last = numbers.pop(); // last = 4, numbers = [1, 2, 3]`,
      hint: "Try adding and removing items from the array in the code editor",
      interactive: true,
      completed: true,
    },
    {
      id: 3,
      title: "Working with Objects",
      content:
        "Objects store data in key-value pairs. You can access properties using dot notation or bracket notation.",
      codeExample: `const student = {
  name: 'Alice',
  age: 20,
  grade: 'A'
};

console.log(student.name); // 'Alice'
console.log(student['age']); // 20`,
      hint: "Objects are like containers that hold related information",
      interactive: true,
      completed: false,
    },
    {
      id: 4,
      title: "Array of Objects",
      content: "You can combine arrays and objects to create more complex data structures.",
      codeExample: `const students = [
  { name: 'Alice', grade: 85 },
  { name: 'Bob', grade: 92 },
  { name: 'Charlie', grade: 78 }
];

// Access the first student's name
console.log(students[0].name); // 'Alice'`,
      interactive: true,
      completed: false,
    },
    {
      id: 5,
      title: "Iterating Through Arrays",
      content: "Use loops or array methods like forEach, map, and filter to work with array data.",
      codeExample: `const numbers = [1, 2, 3, 4, 5];

// Using forEach
numbers.forEach(num => console.log(num * 2));

// Using map to create a new array
const doubled = numbers.map(num => num * 2);

// Using filter to find specific items
const evenNumbers = numbers.filter(num => num % 2 === 0);`,
      hint: "Array methods are powerful tools for data manipulation",
      interactive: true,
      completed: false,
    },
  ],
}

export function TutorialPanel() {
  const [currentStepIndex, setCurrentStepIndex] = useState(2) // Start at step 3 (index 2)
  const [tutorial] = useState<Tutorial>(currentTutorial)

  const currentStep = tutorial.steps[currentStepIndex]
  const completedSteps = tutorial.steps.filter((step) => step.completed).length
  const progressPercentage = (completedSteps / tutorial.steps.length) * 100

  const goToNextStep = () => {
    if (currentStepIndex < tutorial.steps.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1)
    }
  }

  const goToPreviousStep = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(currentStepIndex - 1)
    }
  }

  const markStepCompleted = () => {
    tutorial.steps[currentStepIndex].completed = true
    // Force re-render by updating state
    setCurrentStepIndex(currentStepIndex)
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "intermediate":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "advanced":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            Tutorial
          </CardTitle>
          <Badge className={getDifficultyColor(tutorial.difficulty)}>{tutorial.difficulty}</Badge>
        </div>

        <div className="space-y-2">
          <h3 className="font-medium">{tutorial.title}</h3>
          <p className="text-sm text-muted-foreground">{tutorial.description}</p>

          {/* Progress */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Progress</span>
              <span>
                {completedSteps}/{tutorial.steps.length} steps
              </span>
            </div>
            <Progress value={progressPercentage} className="h-2" />
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Step Navigation */}
        <div className="flex items-center justify-between">
          <Button variant="outline" size="sm" onClick={goToPreviousStep} disabled={currentStepIndex === 0}>
            <ChevronLeft className="w-4 h-4 mr-1" />
            Previous
          </Button>

          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">
              Step {currentStepIndex + 1} of {tutorial.steps.length}
            </span>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={goToNextStep}
            disabled={currentStepIndex === tutorial.steps.length - 1}
          >
            Next
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>

        {/* Step Content */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            {currentStep.completed ? (
              <CheckCircle className="w-5 h-5 text-green-500" />
            ) : (
              <Circle className="w-5 h-5 text-muted-foreground" />
            )}
            <h4 className="font-semibold">{currentStep.title}</h4>
          </div>

          <ScrollArea className="h-64">
            <div className="space-y-4 pr-4">
              <p className="text-sm leading-relaxed">{currentStep.content}</p>

              {/* Code Example */}
              {currentStep.codeExample && (
                <div className="space-y-2">
                  <h5 className="text-sm font-medium flex items-center gap-2">
                    <Code className="w-4 h-4" />
                    Example
                  </h5>
                  <pre className="text-sm font-mono bg-muted p-3 rounded border overflow-x-auto">
                    {currentStep.codeExample}
                  </pre>
                </div>
              )}

              {/* Hint */}
              {currentStep.hint && (
                <div className="p-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg">
                  <div className="flex items-start gap-2">
                    <Lightbulb className="w-4 h-4 text-blue-500 mt-0.5" />
                    <div>
                      <h5 className="text-sm font-medium text-blue-900 dark:text-blue-100">Hint</h5>
                      <p className="text-sm text-blue-700 dark:text-blue-200 mt-1">{currentStep.hint}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Interactive Elements */}
              {currentStep.interactive && (
                <div className="space-y-2">
                  <h5 className="text-sm font-medium">Try it yourself</h5>
                  <div className="flex gap-2">
                    <Button size="sm" variant="secondary">
                      <Play className="w-4 h-4 mr-2" />
                      Run Example
                    </Button>
                    {!currentStep.completed && (
                      <Button size="sm" onClick={markStepCompleted}>
                        Mark Complete
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Step Overview */}
        <div className="border-t pt-4">
          <h5 className="text-sm font-medium mb-2">All Steps</h5>
          <div className="grid grid-cols-5 gap-2">
            {tutorial.steps.map((step, index) => (
              <Button
                key={step.id}
                variant={index === currentStepIndex ? "default" : "outline"}
                size="sm"
                className="h-8 p-0"
                onClick={() => setCurrentStepIndex(index)}
              >
                {step.completed ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <span className="text-xs">{step.id}</span>
                )}
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
