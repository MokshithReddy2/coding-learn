import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { BookOpen, Code, Bug, Lightbulb, Trophy, FileText, ChevronRight, CheckCircle } from "lucide-react"

const lessons = [
  { id: 1, title: "Variables & Data Types", completed: true },
  { id: 2, title: "Functions & Scope", completed: true },
  { id: 3, title: "Arrays & Objects", completed: false, current: true },
  { id: 4, title: "Loops & Conditionals", completed: false },
  { id: 5, title: "Error Handling", completed: false },
]

export function PlatformSidebar() {
  return (
    <aside className="w-80 border-r border-border bg-sidebar">
      <div className="p-4 border-b border-sidebar-border">
        <h2 className="font-semibold text-sidebar-foreground mb-2">Course Progress</h2>
        <div className="flex items-center gap-2 text-sm text-sidebar-foreground">
          <div className="w-full bg-sidebar-accent rounded-full h-2">
            <div className="bg-sidebar-primary h-2 rounded-full" style={{ width: "40%" }}></div>
          </div>
          <span>2/5</span>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-6">
          {/* Navigation */}
          <div>
            <h3 className="text-sm font-medium text-sidebar-foreground mb-3 flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Lessons
            </h3>
            <div className="space-y-2">
              {lessons.map((lesson) => (
                <Button
                  key={lesson.id}
                  variant={lesson.current ? "default" : "ghost"}
                  className="w-full justify-start text-left h-auto p-3"
                >
                  <div className="flex items-center gap-3 w-full">
                    {lesson.completed ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border-2 border-sidebar-border" />
                    )}
                    <div className="flex-1">
                      <div className="text-sm font-medium">{lesson.title}</div>
                    </div>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Tools */}
          <div>
            <h3 className="text-sm font-medium text-sidebar-foreground mb-3 flex items-center gap-2">
              <Code className="w-4 h-4" />
              Tools
            </h3>
            <div className="space-y-1">
              <Button variant="ghost" className="w-full justify-start">
                <Bug className="w-4 h-4 mr-2" />
                Debugger
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Lightbulb className="w-4 h-4 mr-2" />
                Hints
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <FileText className="w-4 h-4 mr-2" />
                Documentation
              </Button>
            </div>
          </div>

          {/* Achievements */}
          <div>
            <h3 className="text-sm font-medium text-sidebar-foreground mb-3 flex items-center gap-2">
              <Trophy className="w-4 h-4" />
              Achievements
            </h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2 p-2 rounded-lg bg-sidebar-accent">
                <Trophy className="w-4 h-4 text-yellow-500" />
                <span className="text-sm">First Function</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-lg bg-sidebar-accent">
                <Trophy className="w-4 h-4 text-yellow-500" />
                <span className="text-sm">Bug Hunter</span>
              </div>
            </div>
          </div>
        </div>
      </ScrollArea>
    </aside>
  )
}
