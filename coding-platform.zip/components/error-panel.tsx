"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { AlertTriangle, X, ChevronDown, ChevronRight, Lightbulb, ExternalLink } from "lucide-react"

interface CodeError {
  id: string
  line: number
  column: number
  message: string
  type: "error" | "warning" | "info"
  severity: "high" | "medium" | "low"
  suggestion?: string
  documentation?: string
  fixable?: boolean
}

const mockErrors: CodeError[] = [
  {
    id: "1",
    line: 12,
    column: 1,
    message: "Function 'calculateAverage' is declared but never implemented",
    type: "error",
    severity: "high",
    suggestion: "Add implementation to calculate the sum of grades divided by array length",
    documentation: "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/reduce",
    fixable: true,
  },
  {
    id: "2",
    line: 17,
    column: 1,
    message: "Function 'getTopStudents' is declared but never implemented",
    type: "error",
    severity: "high",
    suggestion: "Use Array.filter() to return students with grades above 80",
    documentation: "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter",
    fixable: true,
  },
  {
    id: "3",
    line: 21,
    column: 35,
    message: "Function may return 'undefined'",
    type: "warning",
    severity: "medium",
    suggestion: "Ensure all code paths return a value",
    fixable: false,
  },
  {
    id: "4",
    line: 8,
    column: 1,
    message: "Consider using 'const' instead of 'let' for variables that don't change",
    type: "info",
    severity: "low",
    suggestion: "Use 'const' for immutable variables to improve code clarity",
    fixable: true,
  },
]

export function ErrorPanel() {
  const [errors] = useState<CodeError[]>(mockErrors)
  const [expandedErrors, setExpandedErrors] = useState<Set<string>>(new Set())
  const [filter, setFilter] = useState<"all" | "error" | "warning" | "info">("all")

  const filteredErrors = errors.filter((error) => filter === "all" || error.type === filter)

  const toggleError = (errorId: string) => {
    const newExpanded = new Set(expandedErrors)
    if (newExpanded.has(errorId)) {
      newExpanded.delete(errorId)
    } else {
      newExpanded.add(errorId)
    }
    setExpandedErrors(newExpanded)
  }

  const getErrorIcon = (type: string) => {
    switch (type) {
      case "error":
        return <X className="w-4 h-4 text-destructive" />
      case "warning":
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />
      case "info":
        return <Lightbulb className="w-4 h-4 text-blue-500" />
      default:
        return <AlertTriangle className="w-4 h-4" />
    }
  }

  const getErrorBadgeVariant = (type: string) => {
    switch (type) {
      case "error":
        return "destructive"
      case "warning":
        return "secondary"
      case "info":
        return "outline"
      default:
        return "outline"
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "text-red-500"
      case "medium":
        return "text-yellow-500"
      case "low":
        return "text-blue-500"
      default:
        return "text-gray-500"
    }
  }

  const errorCounts = {
    error: errors.filter((e) => e.type === "error").length,
    warning: errors.filter((e) => e.type === "warning").length,
    info: errors.filter((e) => e.type === "info").length,
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Problems
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="destructive" className="text-xs">
              {errorCounts.error} errors
            </Badge>
            <Badge variant="secondary" className="text-xs">
              {errorCounts.warning} warnings
            </Badge>
            <Badge variant="outline" className="text-xs">
              {errorCounts.info} info
            </Badge>
          </div>
        </div>

        {/* Filter buttons */}
        <div className="flex gap-2 mt-2">
          <Button variant={filter === "all" ? "default" : "outline"} size="sm" onClick={() => setFilter("all")}>
            All ({errors.length})
          </Button>
          <Button variant={filter === "error" ? "destructive" : "outline"} size="sm" onClick={() => setFilter("error")}>
            Errors ({errorCounts.error})
          </Button>
          <Button
            variant={filter === "warning" ? "secondary" : "outline"}
            size="sm"
            onClick={() => setFilter("warning")}
          >
            Warnings ({errorCounts.warning})
          </Button>
          <Button variant={filter === "info" ? "default" : "outline"} size="sm" onClick={() => setFilter("info")}>
            Info ({errorCounts.info})
          </Button>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        <ScrollArea className="h-64">
          <div className="p-4 space-y-2">
            {filteredErrors.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Lightbulb className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>No {filter === "all" ? "" : filter} problems found!</p>
              </div>
            ) : (
              filteredErrors.map((error) => (
                <Collapsible key={error.id}>
                  <CollapsibleTrigger className="w-full" onClick={() => toggleError(error.id)}>
                    <div className="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors">
                      {getErrorIcon(error.type)}
                      <div className="flex-1 text-left">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant={getErrorBadgeVariant(error.type)} className="text-xs">
                            {error.type}
                          </Badge>
                          <span className={`text-xs font-medium ${getSeverityColor(error.severity)}`}>
                            {error.severity}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            Line {error.line}:{error.column}
                          </span>
                        </div>
                        <p className="text-sm font-medium">{error.message}</p>
                      </div>
                      {expandedErrors.has(error.id) ? (
                        <ChevronDown className="w-4 h-4 text-muted-foreground" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-muted-foreground" />
                      )}
                    </div>
                  </CollapsibleTrigger>

                  <CollapsibleContent>
                    <div className="ml-10 mr-3 mb-3 p-3 bg-muted/30 rounded-lg border-l-4 border-l-secondary">
                      {error.suggestion && (
                        <div className="mb-3">
                          <h4 className="text-sm font-medium mb-1 flex items-center gap-2">
                            <Lightbulb className="w-4 h-4 text-secondary" />
                            Suggestion
                          </h4>
                          <p className="text-sm text-muted-foreground">{error.suggestion}</p>
                        </div>
                      )}

                      <div className="flex items-center gap-2">
                        {error.fixable && (
                          <Button size="sm" variant="secondary">
                            Quick Fix
                          </Button>
                        )}
                        {error.documentation && (
                          <Button size="sm" variant="outline" asChild>
                            <a href={error.documentation} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="w-3 h-3 mr-1" />
                              Learn More
                            </a>
                          </Button>
                        )}
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
