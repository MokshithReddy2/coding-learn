"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Bug, Play, Pause, StepForward, RotateCcw, Eye, Variable, Clock, Target } from "lucide-react"

interface DebugVariable {
  name: string
  value: any
  type: string
  scope: "global" | "local"
}

interface DebugBreakpoint {
  line: number
  active: boolean
  condition?: string
}

interface DebugStep {
  line: number
  function: string
  variables: DebugVariable[]
  timestamp: number
}

export function DebugPanel() {
  const [isDebugging, setIsDebugging] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [currentLine, setCurrentLine] = useState<number | null>(null)
  const [breakpoints, setBreakpoints] = useState<DebugBreakpoint[]>([
    { line: 12, active: true },
    { line: 17, active: true, condition: "studentArray.length > 0" },
  ])

  const [variables] = useState<DebugVariable[]>([
    { name: "students", value: "[Array(3)]", type: "Array", scope: "global" },
    { name: "studentArray", value: "[Array(3)]", type: "Array", scope: "local" },
    { name: "total", value: "255", type: "number", scope: "local" },
    { name: "count", value: "3", type: "number", scope: "local" },
  ])

  const [debugHistory] = useState<DebugStep[]>([
    {
      line: 12,
      function: "calculateAverage",
      variables: [{ name: "studentArray", value: "[Array(3)]", type: "Array", scope: "local" }],
      timestamp: Date.now() - 5000,
    },
    {
      line: 13,
      function: "calculateAverage",
      variables: [
        { name: "studentArray", value: "[Array(3)]", type: "Array", scope: "local" },
        { name: "total", value: "0", type: "number", scope: "local" },
      ],
      timestamp: Date.now() - 4000,
    },
    {
      line: 17,
      function: "getTopStudents",
      variables: [
        { name: "studentArray", value: "[Array(3)]", type: "Array", scope: "local" },
        { name: "result", value: "[]", type: "Array", scope: "local" },
      ],
      timestamp: Date.now() - 3000,
    },
  ])

  const [watchExpressions, setWatchExpressions] = useState<string[]>([
    "students.length",
    "studentArray[0].grade",
    "total / count",
  ])

  const [newWatch, setNewWatch] = useState("")

  const startDebugging = () => {
    setIsDebugging(true)
    setIsPaused(true)
    setCurrentLine(12)
  }

  const stopDebugging = () => {
    setIsDebugging(false)
    setIsPaused(false)
    setCurrentLine(null)
  }

  const stepOver = () => {
    if (currentLine) {
      setCurrentLine(currentLine + 1)
    }
  }

  const toggleBreakpoint = (line: number) => {
    setBreakpoints((prev) => prev.map((bp) => (bp.line === line ? { ...bp, active: !bp.active } : bp)))
  }

  const addWatchExpression = () => {
    if (newWatch.trim()) {
      setWatchExpressions((prev) => [...prev, newWatch.trim()])
      setNewWatch("")
    }
  }

  const removeWatchExpression = (index: number) => {
    setWatchExpressions((prev) => prev.filter((_, i) => i !== index))
  }

  const getVariableValue = (expression: string) => {
    // Simulate evaluation of watch expressions
    switch (expression) {
      case "students.length":
        return "3"
      case "studentArray[0].grade":
        return "85"
      case "total / count":
        return "85"
      default:
        return "undefined"
    }
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Bug className="w-5 h-5" />
            Debugger
          </CardTitle>
          <div className="flex items-center gap-2">
            {isDebugging ? (
              <>
                <Button variant="outline" size="sm" onClick={stepOver} disabled={!isPaused}>
                  <StepForward className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="sm" onClick={() => setIsPaused(!isPaused)}>
                  {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                </Button>
                <Button variant="outline" size="sm" onClick={stopDebugging}>
                  <RotateCcw className="w-4 h-4" />
                </Button>
              </>
            ) : (
              <Button size="sm" onClick={startDebugging} className="bg-secondary hover:bg-secondary/90">
                <Bug className="w-4 h-4 mr-2" />
                Start Debug
              </Button>
            )}
          </div>
        </div>

        {isDebugging && (
          <div className="flex items-center gap-2 mt-2">
            <Badge variant={isPaused ? "destructive" : "secondary"}>{isPaused ? "Paused" : "Running"}</Badge>
            {currentLine && <Badge variant="outline">Line {currentLine}</Badge>}
          </div>
        )}
      </CardHeader>

      <CardContent className="p-0">
        <Tabs defaultValue="variables" className="h-full">
          <TabsList className="grid w-full grid-cols-4 rounded-none border-b">
            <TabsTrigger value="variables">Variables</TabsTrigger>
            <TabsTrigger value="watch">Watch</TabsTrigger>
            <TabsTrigger value="breakpoints">Breakpoints</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="variables" className="mt-0">
            <ScrollArea className="h-80">
              <div className="p-4 space-y-3">
                {variables.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Variable className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No variables in current scope</p>
                  </div>
                ) : (
                  variables.map((variable, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg border">
                      <div className="flex items-center gap-3">
                        <Variable className="w-4 h-4 text-secondary" />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-sm font-medium">{variable.name}</span>
                            <Badge variant="outline" className="text-xs">
                              {variable.type}
                            </Badge>
                            <Badge variant={variable.scope === "global" ? "secondary" : "outline"} className="text-xs">
                              {variable.scope}
                            </Badge>
                          </div>
                          <div className="font-mono text-sm text-muted-foreground mt-1">{variable.value}</div>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="watch" className="mt-0">
            <div className="p-4">
              <div className="flex gap-2 mb-4">
                <Input
                  placeholder="Add watch expression..."
                  value={newWatch}
                  onChange={(e) => setNewWatch(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && addWatchExpression()}
                  className="font-mono text-sm"
                />
                <Button onClick={addWatchExpression} size="sm">
                  Add
                </Button>
              </div>

              <ScrollArea className="h-64">
                <div className="space-y-2">
                  {watchExpressions.map((expression, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg border">
                      <div className="flex-1">
                        <div className="font-mono text-sm font-medium">{expression}</div>
                        <div className="font-mono text-sm text-muted-foreground">= {getVariableValue(expression)}</div>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => removeWatchExpression(index)}>
                        ×
                      </Button>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="breakpoints" className="mt-0">
            <ScrollArea className="h-80">
              <div className="p-4 space-y-2">
                {breakpoints.map((breakpoint, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleBreakpoint(breakpoint.line)}
                        className={breakpoint.active ? "text-destructive" : "text-muted-foreground"}
                      >
                        <Target className="w-4 h-4" />
                      </Button>
                      <div>
                        <div className="text-sm font-medium">Line {breakpoint.line}</div>
                        {breakpoint.condition && (
                          <div className="text-xs text-muted-foreground font-mono">
                            Condition: {breakpoint.condition}
                          </div>
                        )}
                      </div>
                    </div>
                    <Badge variant={breakpoint.active ? "destructive" : "outline"}>
                      {breakpoint.active ? "Active" : "Disabled"}
                    </Badge>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="history" className="mt-0">
            <ScrollArea className="h-80">
              <div className="p-4 space-y-2">
                {debugHistory.map((step, index) => (
                  <div key={index} className="p-3 rounded-lg border">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-secondary" />
                        <span className="text-sm font-medium">
                          {step.function} - Line {step.line}
                        </span>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {new Date(step.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Variables: {step.variables.map((v) => v.name).join(", ")}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
